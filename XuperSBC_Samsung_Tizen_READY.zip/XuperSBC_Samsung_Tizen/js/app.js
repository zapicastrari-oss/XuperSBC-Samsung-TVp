(function () {
  'use strict';
  var sections = ['tv', 'movies', 'series', 'sports', 'favorites'];
  var labels = {tv:'TV en vivo',movies:'Películas',series:'Series',sports:'Deportes',favorites:'Favoritos'};
  var currentSection = 'tv', items = [], selected = 0, buttons = [], tabs = [];
  var list = document.getElementById('channel-list');
  var video = document.getElementById('video');
  var playing = document.getElementById('playing');
  var title = document.getElementById('section-title');
  var message = document.getElementById('message');
  function parseM3U(data) {
    var lines = data.replace(/\r/g, '').split('\n'), out = [], pending = null, i, line, match;
    for (i = 0; i < lines.length; i++) {
      line = lines[i].replace(/^\s+|\s+$/g, '');
      if (line.indexOf('#EXTINF:') === 0) {
        match = line.match(/,(.*)$/);
        pending = {name: match ? match[1] : 'Canal ' + (out.length + 1), url: ''};
      } else if (line && line.charAt(0) !== '#' && pending) {
        pending.url = line; out.push(pending); pending = null;
      }
    }
    return out;
  }
  function render() {
    var i, b;
    title.innerHTML = labels[currentSection];
    list.innerHTML = '';
    buttons = [];
    if (!items.length) {
      var empty = document.createElement('div'); empty.className = 'empty';
      empty.innerHTML = 'No hay contenido cargado.<br>Configura una lista M3U autorizada en js/config.js.';
      list.appendChild(empty); message.innerHTML = 'Lista multimedia no configurada.'; return;
    }
    message.innerHTML = items.length + ' elementos disponibles';
    for (i = 0; i < items.length; i++) {
      b = document.createElement('button'); b.className = 'channel'; b.innerHTML = escapeText(items[i].name); b.setAttribute('data-index', i);
      b.onclick = (function (index) { return function () { play(index); }; }(i));
      list.appendChild(b); buttons.push(b);
    }
    focusItem(0);
  }
  function escapeText(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function focusItem(n) { if (!buttons.length) return; selected = Math.max(0, Math.min(n, buttons.length - 1)); for (var i=0;i<buttons.length;i++) buttons[i].className = i === selected ? 'channel active' : 'channel'; buttons[selected].focus(); }
  function play(n) { if (!items[n]) return; selected = n; video.src = items[n].url; video.play(); playing.innerHTML = 'Reproduciendo: ' + escapeText(items[n].name); }
  function setSection(s) { if (sections.indexOf(s) < 0) return; currentSection = s; for (var i=0;i<tabs.length;i++) tabs[i].className = tabs[i].getAttribute('data-section') === s ? 'tab selected' : 'tab'; render(); }
  tabs = document.getElementById('tabs').getElementsByTagName('button');
  for (var t=0;t<tabs.length;t++) tabs[t].onclick = function () { setSection(this.getAttribute('data-section')); };
  document.addEventListener('keydown', function (e) {
    var key = e.keyCode || e.which;
    if (key === 37 || key === 38) { e.preventDefault(); focusItem(selected - 1); }
    else if (key === 39 || key === 40) { e.preventDefault(); focusItem(selected + 1); }
    else if (key === 13) { if (buttons.length) play(selected); }
    else if (key === 10009 || key === 8 || key === 27) { try { if (window.tizen && window.tizen.application) window.tizen.application.getCurrentApplication().hide(); } catch (ignore) {} }
  });
  if (window.XUPER_M3U_URL) {
    var xhr = new XMLHttpRequest(); xhr.open('GET', window.XUPER_M3U_URL, true);
    xhr.onreadystatechange = function () { if (xhr.readyState === 4) { if (xhr.status >= 200 && xhr.status < 300) { items = parseM3U(xhr.responseText); render(); } else { message.innerHTML = 'No se pudo cargar la lista M3U. Comprueba la URL y la conexión.'; } } };
    xhr.send(null);
  } else { render(); }
}());
