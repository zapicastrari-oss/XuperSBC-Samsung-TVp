/* Pega aquí la URL de una lista M3U que tengas autorización para usar.
   Ejemplo: window.XUPER_M3U_URL = 'https://tu-servidor/lista.m3u';
   También puedes dejarla vacía y cargar una lista de prueba local durante el desarrollo. */
window.XUPER_M3U_URL = '';
