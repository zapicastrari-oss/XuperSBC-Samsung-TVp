# XuperSBC Samsung Smart TV — proyecto base

Proyecto web de ejemplo para adaptar una interfaz de reproductor a Samsung Smart TV/Tizen. Está preparado como **código fuente**, no es todavía un `.wgt` firmado ni una conversión del APK Android original.

## Contenido
- `config.xml`: manifiesto de aplicación Tizen TV, perfil `tv-samsung`, versión mínima declarada 2.3.
- `index.html`, `css/style.css`, `js/app.js`: interfaz y navegación básica con mando.
- `js/config.js`: lugar para configurar la URL de una lista M3U de la que tengas autorización.
- `icons/icon.png`: icono.

## Configurar una lista propia
Edita `js/config.js` y define `window.XUPER_M3U_URL` con la URL HTTPS de una lista M3U autorizada. No publiques listas privadas, credenciales, tokens ni claves en un repositorio público. El reproductor del televisor puede no admitir todos los códecs, protocolos o DRM; HLS y formatos concretos deben probarse en el modelo real.

## Compilar y firmar
1. Instala la versión de Samsung TV SDK/Tizen Studio que aún proporcione soporte para el perfil antiguo del televisor. La disponibilidad de herramientas antiguas puede ser limitada.
2. Importa este directorio como proyecto de aplicación web TV.
3. Revisa `config.xml` y selecciona el perfil/plataforma compatible con el modelo y firmware del TV.
4. Crea tu propio certificado/perfil de distribución en Certificate Manager siguiendo la documentación oficial de Samsung. Mantén la clave privada y contraseña fuera de GitHub.
5. Empaqueta como `.wgt`, instala primero en modo desarrollador y prueba la navegación y reproducción en el TV.

**Limitaciones:** un proyecto web no puede convertir bibliotecas Android nativas del APK. La app original no se ha reproducido íntegramente. La firma no se incluye: debe generarse con la identidad del desarrollador y las herramientas oficiales. La declaración `required_version="2.3"` no garantiza por sí sola compatibilidad con cada firmware del modelo UN40J6500.
